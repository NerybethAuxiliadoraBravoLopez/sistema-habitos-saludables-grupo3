/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Modelo.Habitos;
import Modelo.HabitosDAO;
import java.util.List;

/**
 *
 * @author jhon Fonseca
 */
public class HabitosController {

    
private final HabitosDAO habitosDAO = new HabitosDAO();

    public boolean guardarHabito(Habitos habitos) {
        return habitosDAO.guardar(habitos);
    }

    public List<Object[]> listarHabitos() {
        return habitosDAO.listarHabitos();
    }

    public boolean eliminarHabito(int id) {
        return habitosDAO.eliminarhabito(id);
    }
}
