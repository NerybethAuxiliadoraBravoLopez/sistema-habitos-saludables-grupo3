/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Modelo.ReporteDAO;
import java.util.List;

/**
 *
 * @author jhon Fonseca
 */
public class ReporteController {
    ReporteDAO gradoDAO =new ReporteDAO();
    
    
    public int contarGrados() {
    return gradoDAO.contarGrados();
}
    
    public int contarEstudiantes() {
    return gradoDAO.contarEstudiantes();
}

public List<Object[]> listarReporteGeneral() {
    return gradoDAO.listarReporteGeneral();
}
}
