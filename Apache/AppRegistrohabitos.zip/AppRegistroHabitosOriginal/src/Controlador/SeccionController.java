/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Modelo.Seccion;
import Modelo.SeccionDAO;
import java.util.List;

/**
 *
 * @author jhon Fonseca
 */
public class SeccionController {
      private SeccionDAO seccionDAO = new SeccionDAO();
      
      public int guardarGrado(Seccion seccion){
        return seccionDAO.guardar(seccion);
    }
      public boolean eliminarseccion (int id){
        return seccionDAO.eliminarseccion(id);
}
   
    public List<Seccion> obtenerSecciones() {
        return seccionDAO.listarSecciones();
    }
}

