package Controlador;
import Modelo.Tutor;
import Modelo.TutorDAO;
public class TutorController {
    private final TutorDAO tutorDAO = new TutorDAO();
    public int guardar(Tutor t) {
        return tutorDAO.guardar(t);
    }
    public Tutor buscarPorId(int id) {
        return tutorDAO.buscarTutor(id);
    }
    public boolean actualizar(Tutor t) {
        return tutorDAO.actualizarTutor(t);
    }
    public boolean eliminar(int id) {
    return tutorDAO.eliminarTutor(id);
}
}