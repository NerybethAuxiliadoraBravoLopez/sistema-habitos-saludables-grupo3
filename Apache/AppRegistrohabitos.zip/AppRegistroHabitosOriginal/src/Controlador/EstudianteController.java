package Controlador;

import Modelo.Estudiante;
import Modelo.EstudianteDAO;
import java.util.List;

public class EstudianteController {
    private final EstudianteDAO estudianteDAO = new EstudianteDAO();

    public boolean guardar(Estudiante e) {
        return estudianteDAO.guardar(e);
    }

    public boolean actualizar(Estudiante e) {
        return estudianteDAO.actualizarEstudiante(e);
    }

    public boolean eliminar(int id) {
        return estudianteDAO.eliminarEstudiante(id);
    }

    public Estudiante buscarPorCodigo(int codigo) {
        return estudianteDAO.buscarEstudiante(codigo);
    }

    public List<Object[]> listar() {
        return estudianteDAO.listarEstudiantes();
    }
    public int contarPorTutor(int idTutor) {
    return estudianteDAO.contarEstudiantesPorTutor(idTutor);
}
}