/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;


import Modelo.UsuarioDAO;
import java.util.List;
import Modelo.Usuario;



/**
 *
 * @author jhon Fonseca
 */
public class UsuarioController {
     
    private final UsuarioDAO usuariodao =new UsuarioDAO();

    public boolean guardarUsuario(Usuario usuario){
            return usuariodao.guardar(usuario);
    }
    public String validarLogin(String nombreusuario, String contrasena) {
        return usuariodao.obtenerRol(nombreusuario, contrasena);
    }
    public boolean puedesgestionarUsuario (String rol){
        return "Administrador".equalsIgnoreCase(rol);
    }
    public boolean puedesregsitrarusuario (String rol) {
        return "Administrador".equalsIgnoreCase(rol);
    }
    //lista de obtener al docente

    public List<Usuario> obtenerDocentes() {
        return usuariodao.obtenerDocentes();
    }
 public List<Object[]> listarUsuarios() {
    return usuariodao.listarUsuario();
}
public boolean eliminarUsuario(int idUsuario) {
    return usuariodao.eliminarUsuario(idUsuario);
}
}
