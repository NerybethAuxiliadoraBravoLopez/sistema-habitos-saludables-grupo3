package Controlador;

import Modelo.Aula;
import Modelo.AulaDAO;
import Modelo.SeccionDAO;
import Modelo.GradoDAO;
import java.util.List;

public class AulaController {

    private AulaDAO aulaDAO = new AulaDAO();
    private SeccionDAO seccionDAO = new SeccionDAO();
    private GradoDAO gradoDAO = new GradoDAO();

    public boolean guardarAula(Aula aula) {
        return aulaDAO.guardar(aula);
    }

    public List<Object[]> obtenerAulasConDocente() {
        return aulaDAO.obtenerTodasConDocente();
    }
    
    public boolean eliminarAula (int id){
        return aulaDAO.eliminarAula(id);
    }
   

    /**
     * Elimina el aula junto con su sección y grado asociados.
     * OJO: esto asume que sección y grado son EXCLUSIVOS de cada aula.
     * Si varias aulas pueden compartir el mismo grado/sección, esto
     * romperá esas otras aulas. Lee la nota al final.
     */
public boolean eliminarAulaCompleta(int idAula) {
    Aula aula = aulaDAO.buscarPorId(idAula);
    if (aula == null) {
        return false;
    }

    int idSeccion = aula.getIdSeccion();
    int idGrado = aula.getId_grado();

    // 1. Borrar el aula primero
    boolean aulaEliminada = aulaDAO.eliminarAula(idAula);
    if (!aulaEliminada) {
        return false;
    }

    // 2. Borrar sección SOLO si ninguna otra aula NI ningún estudiante la usa
    int usosSeccion = aulaDAO.contarAulasPorSeccion(idSeccion)
                    + aulaDAO.contarEstudiantesPorSeccion(idSeccion);
    if (usosSeccion == 0) {
        seccionDAO.eliminarseccion(idSeccion);
    }

    // 3. Borrar grado SOLO si ninguna otra aula NI ningún estudiante lo usa
    int usosGrado = aulaDAO.contarAulasPorGrado(idGrado)
                  + aulaDAO.contarEstudiantesPorGrado(idGrado);
    if (usosGrado == 0) {
        gradoDAO.eliminargrado(idGrado);
    }

    return true;
}
}

