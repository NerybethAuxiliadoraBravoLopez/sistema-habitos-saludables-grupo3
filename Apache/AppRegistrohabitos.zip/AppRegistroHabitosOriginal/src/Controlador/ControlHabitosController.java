package Controlador;
import Modelo.Estudiante;
import Modelo.EstudianteDAO;
import Modelo.EstudiantesHabitos;
import Modelo.EstudiantesHabitosDAO;
import Modelo.HabitosDAO;
import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;

public class ControlHabitosController {
    private final EstudianteDAO estudianteDAO;
    private final HabitosDAO habitosDAO;
    private final EstudiantesHabitosDAO estudiantesHabitosDAO;

    public ControlHabitosController() {
        this.estudianteDAO = new EstudianteDAO();
        this.habitosDAO = new HabitosDAO();
        this.estudiantesHabitosDAO = new EstudiantesHabitosDAO();
    }

    public Estudiante buscarEstudiante(int codigo) {
        return estudianteDAO.buscarEstudiante(codigo);
    }

    public List<Object[]> obtenerHabitos() {
        return habitosDAO.listarHabitos();
    }

    public List<EstudiantesHabitos> obtenerHistorial(int codigoEstudiante) {
        return estudiantesHabitosDAO.listarPorEstudiante(codigoEstudiante);
    }

    public static class ResultadoOperacion {
        public final boolean exito;
        public final String mensaje;
        public ResultadoOperacion(boolean exito, String mensaje) {
            this.exito = exito;
            this.mensaje = mensaje;
        }
    }

    private ResultadoOperacion ultimoError;

    public ResultadoOperacion registrarHabito(int codigoEstudiante, Integer idHabito, String textoFecha, String textoCantidad) {
        EstudiantesHabitos registro = validarYArmarRegistro(codigoEstudiante, idHabito, textoFecha, textoCantidad);
        if (registro == null) {
            return ultimoError;
        }

        boolean exito = estudiantesHabitosDAO.registrarHabito(registro);
        return exito
            ? new ResultadoOperacion(true, "Hábito registrado correctamente")
            : new ResultadoOperacion(false, "No se pudo registrar el hábito");
    }

    public ResultadoOperacion actualizarHabito(int idRegistro, int codigoEstudiante, Integer idHabito, String textoFecha, String textoCantidad) {
        EstudiantesHabitos registro = validarYArmarRegistro(codigoEstudiante, idHabito, textoFecha, textoCantidad);
        if (registro == null) {
            return ultimoError;
        }
        registro.setIdRegistro(idRegistro);

        boolean exito = estudiantesHabitosDAO.actualizarHabito(registro);
        return exito
            ? new ResultadoOperacion(true, "Registro actualizado correctamente")
            : new ResultadoOperacion(false, "No se pudo actualizar el registro");
    }

    public ResultadoOperacion eliminarHabito(int idRegistro) {
        boolean exito = estudiantesHabitosDAO.eliminarHabito(idRegistro);
        return exito
            ? new ResultadoOperacion(true, "Registro eliminado correctamente")
            : new ResultadoOperacion(false, "No se pudo eliminar el registro");
    }

    private EstudiantesHabitos validarYArmarRegistro(int codigoEstudiante, Integer idHabito, String textoFecha, String textoCantidad) {
        if (codigoEstudiante == 0) {
            ultimoError = new ResultadoOperacion(false, "No hay un estudiante cargado");
            return null;
        }
        if (idHabito == null) {
            ultimoError = new ResultadoOperacion(false, "Selecciona un hábito");
            return null;
        }
        if (textoFecha == null || textoFecha.trim().isEmpty()
                || textoCantidad == null || textoCantidad.trim().isEmpty()) {
            ultimoError = new ResultadoOperacion(false, "Completa fecha y cantidad");
            return null;
        }

        Date fecha;
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yy");
            sdf.setLenient(false);
            fecha = new Date(sdf.parse(textoFecha.trim()).getTime());
        } catch (ParseException ex) {
            ultimoError = new ResultadoOperacion(false, "Fecha inválida");
            return null;
        }

        double cantidad;
        try {
            cantidad = Double.parseDouble(textoCantidad.trim());
        } catch (NumberFormatException ex) {
            ultimoError = new ResultadoOperacion(false, "La cantidad debe ser un número");
            return null;
        }

        EstudiantesHabitos registro = new EstudiantesHabitos();
        registro.setFecha(fecha);
        registro.setCantidad(cantidad);
        registro.setCodigoEstudiante(codigoEstudiante);
        registro.setIdHabitos(idHabito);
        return registro;
    }
}