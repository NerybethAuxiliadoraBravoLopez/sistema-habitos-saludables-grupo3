/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Modelo.Grado;
import Modelo.GradoDAO;
import java.util.List;

/**
 *
 * @author jhon Fonseca
 */
public class GradoController {
     GradoDAO gradodao=new GradoDAO();
   public int guardarGrado(Grado grado){
        
        return gradodao.guardar(grado);
    }   
       public boolean eliminargrado (int grado){
           
        return gradodao.eliminargrado(grado);
}
       private final GradoDAO gradoDAO = new GradoDAO();
  

    public List<Grado> obtenerGrados() {
        return gradoDAO.listarGrados();
    }

   
}