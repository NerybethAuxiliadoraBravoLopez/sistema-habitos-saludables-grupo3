/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;
 import Conexion.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author jhon Fonseca
 */
public class HabitosDAO {
    
  public boolean guardar(Habitos habitos) {
        String sql = "INSERT INTO habitos (tipo_de_habito, nombre_de_habito, unidad_de_medida) VALUES (?, ?, ?)";

        try (Connection conexion = Conexion.conectar();
             PreparedStatement ps = conexion.prepareStatement(sql)) {

            ps.setString(1, habitos.getTipo_de_habito());
            ps.setString(2, habitos.getNombre_de_habito());
            ps.setString(3, habitos.getUnidad_de_medida());

            ps.executeUpdate();
            return true;

        } catch (SQLException e) {
            System.out.println("Error al guardar: " + e.getMessage());
            return false;
        }
    }

    public List<Object[]> listarHabitos() {
        List<Object[]> lista = new ArrayList<>();
        // 1. Seleccionamos las 5 columnas correspondientes a la tabla de tu vista
        String sql = "SELECT id_habitos, nombre_de_habito, tipo_de_habito, unidad_de_medida, frecuencia FROM habitos";

        try (Connection con = Conexion.conectar();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                // 2. Arreglo de 5 posiciones coincidiendo exactamente con la consulta
                Object[] fila = new Object[5];
                fila[0] = rs.getInt("id_habitos");
                fila[1] = rs.getString("nombre_de_habito");
                fila[2] = rs.getString("tipo_de_habito");
                fila[3] = rs.getString("unidad_de_medida");
                fila[4] = rs.getString("frecuencia");
                
                lista.add(fila);
            }
        } catch (SQLException e) {
            System.err.println("Error SQL al listar: " + e.getMessage());
        }
        return lista;
    }

    public boolean eliminarhabito(int id) {
        String sql = "DELETE FROM habitos WHERE id_habitos = ?";

        try (Connection con = Conexion.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);
            int resultado = ps.executeUpdate();
            return resultado > 0;

        } catch (SQLException ex) {
            System.out.println("Error al eliminar hábito: " + ex.getMessage());
            return false;
        }
    }
        }
