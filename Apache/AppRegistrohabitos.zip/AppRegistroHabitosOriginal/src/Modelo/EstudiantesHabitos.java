/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import java.sql.Date;

/**
 *
 * @author jhon Fonseca
 */
public class EstudiantesHabitos {

    private int idRegistro;
    private Date fecha;
    private double cantidad;
    private int codigoEstudiante;
    private int idHabitos;
    private String nombreHabito;
    private String unidadMedida;

    public EstudiantesHabitos() {
    }

    public EstudiantesHabitos(int idRegistro, Date fecha, double cantidad, int codigoEstudiante, int idHabitos, String nombreHabito, String unidadMedida) {
        this.idRegistro = idRegistro;
        this.fecha = fecha;
        this.cantidad = cantidad;
        this.codigoEstudiante = codigoEstudiante;
        this.idHabitos = idHabitos;
        this.nombreHabito = nombreHabito;
        this.unidadMedida = unidadMedida;
    }

    public int getIdRegistro() {
        return idRegistro;
    }

    public void setIdRegistro(int idRegistro) {
        this.idRegistro = idRegistro;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public double getCantidad() {
        return cantidad;
    }

    public void setCantidad(double cantidad) {
        this.cantidad = cantidad;
    }

    public int getCodigoEstudiante() {
        return codigoEstudiante;
    }

    public void setCodigoEstudiante(int codigoEstudiante) {
        this.codigoEstudiante = codigoEstudiante;
    }

    public int getIdHabitos() {
        return idHabitos;
    }

    public void setIdHabitos(int idHabitos) {
        this.idHabitos = idHabitos;
    }

    public String getNombreHabito() {
        return nombreHabito;
    }

    public void setNombreHabito(String nombreHabito) {
        this.nombreHabito = nombreHabito;
    }

    public String getUnidadMedida() {
        return unidadMedida;
    }

    public void setUnidadMedida(String unidadMedida) {
        this.unidadMedida = unidadMedida;
    }
    
}