package Modelo;


import Conexion.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class TutorDAO {

    public int guardar(Tutor tutor) {

        String sql = "INSERT INTO tutor "
                   + "(nombres, apellidos, correos, telefono) "
                   + "VALUES (?, ?, ?, ?)";

        try (Connection conexion = Conexion.conectar();
             PreparedStatement ps = conexion.prepareStatement(
                     sql,
                     PreparedStatement.RETURN_GENERATED_KEYS)) {

            ps.setString(1, tutor.getNombres());
            ps.setString(2, tutor.getApellidos());
            ps.setString(3, tutor.getCorreos());
            ps.setString(4, tutor.getTelefono());

            ps.executeUpdate();

            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) {
                    return rs.getInt(1);
                }
            }

            return -1;

        } catch (SQLException e) {
            System.out.println("Error al guardar tutor: " + e.getMessage());
            return -1;
        }
    }

   
    
    public boolean eliminarTutor(int id) {
    String sql = "DELETE FROM tutor WHERE id_tutor = ?";
    try (Connection con = Conexion.conectar();
         PreparedStatement ps = con.prepareStatement(sql)) {
        ps.setInt(1, id);
        int resultado = ps.executeUpdate();
        return resultado > 0;
    } catch (SQLException ex) {
        System.out.println("Error al eliminar tutor: " + ex.getMessage());
        return false;
    }
}

    public boolean actualizarTutor(Tutor tutor) {

        String sql = "UPDATE tutor SET "
                   + "nombres = ?, "
                   + "apellidos = ?, "
                   + "correos = ?, "
                   + "telefono = ? "
                   + "WHERE id_tutor = ?";

        try (Connection con = Conexion.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, tutor.getNombres());
            ps.setString(2, tutor.getApellidos());
            ps.setString(3, tutor.getCorreos());
            ps.setString(4, tutor.getTelefono());
            ps.setInt(5, tutor.getId_tutor());

            int resultado = ps.executeUpdate();

            return resultado > 0;

        } catch (SQLException ex) {
            System.out.println("Error al actualizar tutor: " + ex.getMessage());
            return false;
        }
    }

    public Tutor buscarTutor(int id) {

        String sql = "SELECT * FROM tutor WHERE id_tutor = ?";

        try (Connection con = Conexion.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);

            try (ResultSet rs = ps.executeQuery()) {

                if (rs.next()) {

                    Tutor t = new Tutor();

                    t.setId_tutor(rs.getInt("id_tutor"));
                    t.setNombres(rs.getString("nombres"));
                    t.setApellidos(rs.getString("apellidos"));
                    t.setCorreos(rs.getString("correos"));
                    t.setTelefono(rs.getString("telefono"));

                    return t;
                }
            }

        } catch (SQLException ex) {
            System.out.println("Error al buscar tutor: " + ex.getMessage());
        }

        return null;
    }
    
}
