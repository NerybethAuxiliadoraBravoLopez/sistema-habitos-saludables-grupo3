/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import Conexion.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author jhon Fonseca
 */
public class EstudiantesHabitosDAO {

    public boolean registrarHabito(EstudiantesHabitos r) {
        String sql = "INSERT INTO estudiantehabitos (fecha, cantidad, codigo_estudiante, id_habitos) VALUES (?, ?, ?, ?)";
        try (Connection con = Conexion.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setDate(1, r.getFecha());
            ps.setDouble(2, r.getCantidad());
            ps.setInt(3, r.getCodigoEstudiante());
            ps.setInt(4, r.getIdHabitos());
            return ps.executeUpdate() > 0;
        } catch (SQLException ex) {
            ex.printStackTrace();
            return false;
        }
    }
public List<EstudiantesHabitos> listarPorEstudiante(int codigoEstudiante) {
    List<EstudiantesHabitos> lista = new ArrayList<>();

    String sql = "SELECT eh.id_registro, eh.fecha, eh.cantidad, eh.codigo_estudiante, "
               + "eh.id_habitos, h.nombre_de_habito AS nombre_habito, "
               + "h.unidad_de_medida "
               + "FROM estudiantehabitos eh "
               + "JOIN habitos h ON eh.id_habitos = h.id_habitos "
               + "WHERE eh.codigo_estudiante = ? "
               + "ORDER BY eh.fecha DESC";

    try (Connection con = Conexion.conectar();
         PreparedStatement ps = con.prepareStatement(sql)) {

        ps.setInt(1, codigoEstudiante);

        try (ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                EstudiantesHabitos eh = new EstudiantesHabitos();
                eh.setIdRegistro(rs.getInt("id_registro"));
                eh.setFecha(rs.getDate("fecha"));
                eh.setCantidad(rs.getDouble("cantidad"));
                eh.setCodigoEstudiante(rs.getInt("codigo_estudiante"));
                eh.setIdHabitos(rs.getInt("id_habitos"));
                eh.setNombreHabito(rs.getString("nombre_habito"));
                eh.setUnidadMedida(rs.getString("unidad_de_medida"));                
                lista.add(eh);
            }
        }

    } catch (SQLException ex) {
        ex.printStackTrace();
    }

    return lista;
}
    public boolean eliminarHabito(int idRegistro) {
    String sql = "DELETE FROM estudiantehabitos WHERE id_registro = ?";
    try (Connection con = Conexion.conectar();
         PreparedStatement ps = con.prepareStatement(sql)) {
        ps.setInt(1, idRegistro);
        return ps.executeUpdate() > 0;
    } catch (SQLException ex) {
        ex.printStackTrace();
        return false;
    }
}
    public boolean actualizarHabito(EstudiantesHabitos r) {
    String sql = "UPDATE estudiantehabitos SET fecha = ?, cantidad = ?, id_habitos = ? WHERE id_registro = ?";
    try (Connection con = Conexion.conectar();
         PreparedStatement ps = con.prepareStatement(sql)) {
        ps.setDate(1, r.getFecha());
        ps.setDouble(2, r.getCantidad());
        ps.setInt(3, r.getIdHabitos());
        ps.setInt(4, r.getIdRegistro());
        return ps.executeUpdate() > 0;
    } catch (SQLException ex) {
        ex.printStackTrace();
        return false;
    }
}
}