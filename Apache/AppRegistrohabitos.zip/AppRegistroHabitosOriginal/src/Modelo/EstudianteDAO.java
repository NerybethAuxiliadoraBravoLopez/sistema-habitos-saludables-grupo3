
package Modelo;

import Conexion.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class EstudianteDAO {
  
    // Guardar estudiante
   public boolean guardar(Estudiante e) {
        String sql = "INSERT INTO estudiante "
                + "(codigo_estudiante, nombres, apellidos, fecha_nacimiento, genero, id_tutor, id_grado, id_seccion) "
                + "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection con = Conexion.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, e.getCodigo_estudiante());
            ps.setString(2, e.getNombres());
            ps.setString(3, e.getApellidos());
            ps.setInt(4, e.getFecha_nacimiento());
            ps.setString(5, e.getGenero());
            ps.setInt(6, e.getId_tutor());
            ps.setInt(7, e.getId_grado());
            ps.setInt(8, e.getId_seccion());

            int resultado = ps.executeUpdate();
            return resultado > 0;

        } catch (SQLException ex) {
            System.out.println("Error al guardar: " + ex.getMessage());
            return false;
        }
    }

    // Eliminar estudiante
    public boolean eliminarEstudiante(int id) {
        String sql = "DELETE FROM estudiante WHERE codigo_estudiante = ?";

        try (Connection con = Conexion.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);
            int resultado = ps.executeUpdate();
            return resultado > 0;

        } catch (SQLException ex) {
            System.out.println("Error al eliminar estudiante: " + ex.getMessage());
            return false;
        }
    }

    // Actualizar estudiante
    // Actualizar estudiante
public boolean actualizarEstudiante(Estudiante e) {

    String sql = "UPDATE estudiante SET "
            + "nombres = ?, "
            + "apellidos = ?, "
            + "fecha_nacimiento = ?, "
            + "genero = ?, "
            + "id_tutor = ?, "
            + "id_grado = ?, "
            + "id_seccion = ? "
            + "WHERE codigo_estudiante = ?";

    try (Connection con = Conexion.conectar();
         PreparedStatement ps = con.prepareStatement(sql)) {

        ps.setString(1, e.getNombres());
        ps.setString(2, e.getApellidos());
        ps.setInt(3, e.getFecha_nacimiento());
        ps.setString(4, e.getGenero());
        ps.setInt(5, e.getId_tutor());
        ps.setInt(6, e.getId_grado());
        ps.setInt(7, e.getId_seccion());
        ps.setInt(8, e.getCodigo_estudiante());

        int resultado = ps.executeUpdate();

        return resultado > 0;

    } catch (SQLException ex) {
        System.out.println("Error al actualizar estudiante: " + ex.getMessage());
        return false;
    }
}
    // Buscar estudiante por id
    public Estudiante buscarEstudiante(int id) {
        String sql = "SELECT * FROM estudiante WHERE codigo_estudiante = ?";

        try (Connection con = Conexion.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    Estudiante e = new Estudiante();
                    e.setCodigo_estudiante(rs.getInt("codigo_estudiante"));
                    e.setNombres(rs.getString("nombres"));
                    e.setApellidos(rs.getString("apellidos"));
                    e.setFecha_nacimiento(rs.getInt("fecha_nacimiento"));
                    e.setGenero(rs.getString("genero"));
                    e.setId_tutor(rs.getInt("id_tutor"));
                    e.setId_grado(rs.getInt("id_grado"));
                    e.setId_seccion(rs.getInt("id_seccion"));
                    return e;
                }
            }
        } catch (SQLException ex) {
            System.out.println("Error al buscar: " + ex.getMessage());
        }
        return null;
    }

    public List<Object[]> listarEstudiantes() {

    List<Object[]> lista = new ArrayList<>();

    String sql = "SELECT e.codigo_estudiante, "
            + "e.nombres, "
            + "e.apellidos, "
            + "g.numero_grado, "
            + "s.letra_grupo "
            + "FROM estudiante e "
            + "INNER JOIN grado g ON e.id_grado = g.id_grado "
            + "INNER JOIN seccion s ON e.id_seccion = s.id_seccion";

    try (Connection con = Conexion.conectar();
         PreparedStatement ps = con.prepareStatement(sql);
         ResultSet rs = ps.executeQuery()) {

        while (rs.next()) {

            Object[] estudiante = {
                rs.getInt("codigo_estudiante"),
                rs.getString("nombres"),
                rs.getString("apellidos"),
                rs.getInt("numero_grado"),
                rs.getString("letra_grupo")
            };

            lista.add(estudiante);
        }

    } catch (SQLException ex) {
        System.out.println("Error al listar estudiantes: " + ex.getMessage());
    }

    return lista;
}
  public int contarEstudiantesPorTutor(int idTutor) {
    String sql = "SELECT COUNT(*) FROM estudiante WHERE id_tutor = ?";

    try (Connection con = Conexion.conectar();
         PreparedStatement ps = con.prepareStatement(sql)) {

        ps.setInt(1, idTutor);

        try (ResultSet rs = ps.executeQuery()) {
            if (rs.next()) {
                return rs.getInt(1);
            }
        }
    } catch (SQLException ex) {
        System.out.println("Error al contar estudiantes por tutor: " + ex.getMessage());
    }
    return -1; // -1 indica error de consulta, para no confundir con "0 estudiantes"
}
  
}


