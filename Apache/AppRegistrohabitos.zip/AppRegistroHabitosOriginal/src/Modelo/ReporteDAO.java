
package Modelo;

import Conexion.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


public class ReporteDAO {
    // contar los eestudiantes
  public int contarEstudiantes() {
    String sql = "SELECT COUNT(*) FROM estudiante";
    try (Connection con = Conexion.conectar();
         PreparedStatement ps = con.prepareStatement(sql);
         ResultSet rs = ps.executeQuery()) {
        if (rs.next()) {
            return rs.getInt(1);
        }
    } catch (SQLException ex) {
        System.out.println("Error al contar estudiantes: " + ex.getMessage());
    }
    return 0;
}
  // mostrar en la tabla  de reporte
public List<Object[]> listarReporteGeneral() {
    List<Object[]> lista = new ArrayList<>();

    String sql = "SELECT e.codigo_estudiante, "
            + "CONCAT(e.nombres, ' ', e.apellidos) AS nombre_completo, "
            + "GROUP_CONCAT(h.nombre_de_habito SEPARATOR ', ') AS habitos, "
            + "MAX(eh.fecha) AS fecha "
            + "FROM estudiante e "
            + "LEFT JOIN estudiantehabitos eh ON e.codigo_estudiante = eh.codigo_estudiante "
            + "LEFT JOIN habitos h ON eh.id_habitos = h.id_habitos "
            + "GROUP BY e.codigo_estudiante, e.nombres, e.apellidos";

    try (Connection con = Conexion.conectar();
         PreparedStatement ps = con.prepareStatement(sql);
         ResultSet rs = ps.executeQuery()) {

        while (rs.next()) {
            Object[] fila = {
                rs.getInt("codigo_estudiante"),                           // 1. Código
                rs.getString("fecha") != null ? rs.getString("fecha") : "Sin registros", // 2. Fecha
                rs.getString("nombre_completo"),                          // 3. Nombre
                rs.getString("habitos")                                   // 4. Hábitos
            };
            lista.add(fila);
        }

    } catch (SQLException ex) {
        System.out.println("Error al listar reporte general: " + ex.getMessage());
    }

    return lista;
}
   // es par asumar los grados totales
    public int contarGrados() {
    String sql = "SELECT COUNT(*) FROM grado";
    try (Connection con = Conexion.conectar();
         PreparedStatement ps = con.prepareStatement(sql);
         ResultSet rs = ps.executeQuery()) {
        if (rs.next()) {
            return rs.getInt(1);
        }
    } catch (SQLException ex) {
        System.out.println("Error al contar grados: " + ex.getMessage());
    }
    return 0;
}
    
    
    
}
