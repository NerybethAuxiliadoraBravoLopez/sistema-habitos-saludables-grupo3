/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author jhon Fonseca
 */
public class Aula {
     private int idAula;
    private String nombreAula;
    private int capacidad;
    private String descripcion;
    private int idSeccion;     
    private Integer id_grado;
    private int id_usuario;

    public Aula() {
    }

    public Aula(int idAula, String nombreAula, int capacidad, String descripcion, int idSeccion, Integer id_grado, int id_usuario) {
        this.idAula = idAula;
        this.nombreAula = nombreAula;
        this.capacidad = capacidad;
        this.descripcion = descripcion;
        this.idSeccion = idSeccion;
        this.id_grado = id_grado;
        this.id_usuario = id_usuario;
    }

    public Aula(int idAula, String nombreAula, int capacidad, String descripcion, int idSeccion, Integer id_grado) {
        this.idAula = idAula;
        this.nombreAula = nombreAula;
        this.capacidad = capacidad;
        this.descripcion = descripcion;
        this.idSeccion = idSeccion;
        this.id_grado = id_grado;
    }

    public int getIdAula() {
        return idAula;
    }

    public void setIdAula(int idAula) {
        this.idAula = idAula;
    }

    public String getNombreAula() {
        return nombreAula;
    }

    public void setNombreAula(String nombreAula) {
        this.nombreAula = nombreAula;
    }

    public int getCapacidad() {
        return capacidad;
    }

    public void setCapacidad(int capacidad) {
        this.capacidad = capacidad;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public int getIdSeccion() {
        return idSeccion;
    }

    public void setIdSeccion(int idSeccion) {
        this.idSeccion = idSeccion;
    }

    public Integer getId_grado() {
        return id_grado;
    }

    public void setId_grado(Integer id_grado) {
        this.id_grado = id_grado;
    }

    public int getId_usuario() {
        return id_usuario;
    }

    public void setId_usuario(int id_usuario) {
        this.id_usuario = id_usuario;
    }

}