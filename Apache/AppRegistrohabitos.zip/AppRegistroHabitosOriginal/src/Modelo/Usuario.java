
package Modelo;

public class Usuario {
    
    private int id;
    private String nombres;
    private String apellidos;
    private String correo;
    private String nombreusario;
    private String contrasena;
    private String rol;

    public Usuario() {
    }

    public Usuario(int id, String nombreusario, String rol) {
        this.id = id;
        this.nombreusario = nombreusario;
        this.rol = rol;
    }

    public Usuario(int id, String nombres, String apellidos, String correo, String nombreusario, String contrasena, String rol) {
        this.id = id;
        this.nombres = nombres;
        this.apellidos = apellidos;
        this.correo = correo;
        this.nombreusario = nombreusario;
        this.contrasena = contrasena;
        this.rol = rol;
        
    }

    public Usuario(String nombres, String apellidos, String correo, String nombreusario, String contrasena, String rol) {
        this.nombres = nombres;
        this.apellidos = apellidos;
        this.correo = correo;
        this.nombreusario = nombreusario;
        this.contrasena = contrasena;
        this.rol = rol;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombres() {
        return nombres;
    }

    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getNombreusario() {
        return nombreusario;
    }

    public void setNombreusario(String nombreusario) {
        this.nombreusario = nombreusario;
    }

    public String getContrasena() {
        return contrasena;
    }

    public void setContrasena(String contrasena) {
        this.contrasena = contrasena;
    }

    public String getRol() {
        return rol;
    }

    public void setRol(String rol) {
        this.rol = rol;
    }
  

}