/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;
import Conexion.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;   
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author jhon Fonseca
 */
public class SeccionDAO {
       
    
  public int guardar(Seccion seccion) {
    String sql = "INSERT INTO seccion (letra_grupo) VALUES (?)";
    try (Connection conexion = Conexion.conectar();
         PreparedStatement ps = conexion.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS)) {
        ps.setString(1, seccion.getLetra_grupo());
        ps.executeUpdate();
        try (ResultSet rs = ps.getGeneratedKeys()) {
            if (rs.next()) {
                return rs.getInt(1);
            }
        }
        return -1;
    } catch (SQLException e) {
        System.out.println("Error al guardar sección: " + e.getMessage());
        return -1;
    }
}


public List<Seccion> listarSecciones() {
    List<Seccion> lista = new ArrayList<>();
    String sql = "SELECT * FROM seccion ORDER BY letra_grupo";

    try (Connection con = Conexion.conectar();
         PreparedStatement ps = con.prepareStatement(sql);
         ResultSet rs = ps.executeQuery()) {

        while (rs.next()) {
            Seccion s = new Seccion();
            s.setId_seccion(rs.getInt("id_seccion"));
            s.setLetra_grupo(rs.getString("letra_grupo"));
            lista.add(s);
        }

    } catch (SQLException ex) {
        System.out.println("Error al listar secciones: " + ex.getMessage());
    }
    return lista;
}
public boolean eliminarseccion(int id){
    String sql = "DELETE FROM seccion WHERE id_seccion=?";
    try (Connection con = Conexion.conectar();
         PreparedStatement ps = con.prepareStatement(sql)) {

        ps.setInt(1, id);
        int resultado = ps.executeUpdate();
        return resultado > 0;

    } catch (SQLException ex) {
        // Cambia esto temporalmente para verlo en pantalla y no solo en consola
        javax.swing.JOptionPane.showMessageDialog(null, "Error al eliminar seccion: " + ex.getMessage());
        return false;
    }
}
        
}
