
package Modelo;

import java.util.ArrayList;
import java.util.List;
import Conexion.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.ResultSet;


public class UsuarioDAO {
    
    
public boolean guardar(Usuario usuario) {
        
        String sql = "INSERT INTO usuario "
                + "(nombres, apellidos, correo, nombreusuario, contrasena, rol) "
                + "VALUES (?, ?, ?, ?, ?, ?)";
    
        try (Connection conexion = Conexion.conectar();
             PreparedStatement ps = conexion.prepareStatement(sql)) {
            
               
            ps.setString(1, usuario.getNombres());
            ps.setString(2, usuario.getApellidos());
            ps.setString(3, usuario.getCorreo());
             ps.setString(4, usuario.getNombreusario());
            ps.setString(5, usuario.getContrasena());
            ps.setString(6, usuario.getRol());
            
            ps.executeUpdate();
            return true;
            
        } catch (SQLException e) {
            System.out.println("Error al guardar: " + e.getMessage());
            return false;
        }
    }

//Es para validar el inio de sesion
public String obtenerRol(String nombreusuario, String contrasena) {
    String sql = "SELECT rol FROM usuario WHERE nombreusuario = ? AND contrasena = ?";

    try (Connection conexion = Conexion.conectar();
         PreparedStatement ps = conexion.prepareStatement(sql)) {

        ps.setString(1, nombreusuario);
        ps.setString(2, contrasena);

        try (ResultSet rs = ps.executeQuery()) {
            if (rs.next()) {
                return rs.getString("rol");
            }
        }

    } catch (SQLException e) {
        System.out.println("Error al obtener rol: " + e.getMessage());
    }

    return null;
}

//obtener al docente
public List<Usuario> obtenerDocentes() {
    List<Usuario> lista = new ArrayList<>();
    String sql = "SELECT id_usuario, nombres, apellidos, nombreusuario FROM usuario WHERE rol = ?";
    try (Connection conexion = Conexion.conectar();
         PreparedStatement ps = conexion.prepareStatement(sql)) {
        ps.setString(1, "Docente");
        try (ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                Usuario u = new Usuario();
                u.setId(rs.getInt("id_usuario"));
                u.setNombres(rs.getString("nombres"));
                u.setApellidos(rs.getString("apellidos"));
                u.setNombreusario(rs.getString("nombreusuario"));
                lista.add(u);
            }
        }
    } catch (SQLException e) {
        System.out.println("Error al obtener docentes: " + e.getMessage());
    }
    return lista;
}

    public List<Object[]> listarUsuario() {

    List<Object[]> lista = new ArrayList<>();

    String sql = "SELECT u.id_usuario, "
            + "u.nombres, "
            + "u.apellidos, "
            + "u.nombreusuario, "
            + "u.rol "
            + "FROM usuario u "
            ;

    try (Connection con = Conexion.conectar();
         PreparedStatement ps = con.prepareStatement(sql);
         ResultSet rs = ps.executeQuery()) {

        while (rs.next()) {

            Object[] usuario = {
                rs.getInt("id_usuario"),
                rs.getString("nombres"),
                rs.getString("apellidos"),
                rs.getString("nombreusuario"),
                rs.getString("rol")
            };

            lista.add(usuario);
        }

    } catch (SQLException ex) {
        System.out.println("Error al listar Usuario: " + ex.getMessage());
    }

    return lista;
}
  public boolean eliminarUsuario(int idUsuario) {
    String sql = "DELETE FROM usuario WHERE id_usuario = ?";
    try (Connection conexion = Conexion.conectar();
         PreparedStatement ps = conexion.prepareStatement(sql)) {
        ps.setInt(1, idUsuario);
        int filasAfectadas = ps.executeUpdate();
        return filasAfectadas > 0;
    } catch (SQLException e) {
        System.out.println("Error al eliminar usuario: " + e.getMessage());
        return false;
    }
}

}
