package Modelo;

import Conexion.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.sql.ResultSet;

public class AulaDAO {

    public boolean guardar(Aula aula) {
        String sql = "INSERT INTO aula (nombre_aula, capacidad, descripcion, id_seccion, id_grado, id_usuario) "
                   + "VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection conexion = Conexion.conectar();
             PreparedStatement ps = conexion.prepareStatement(sql)) {
            ps.setString(1, aula.getNombreAula());
            ps.setInt(2, aula.getCapacidad());
            ps.setString(3, aula.getDescripcion());
            ps.setInt(4, aula.getIdSeccion());
            ps.setInt(5, aula.getId_grado());
            ps.setInt(6, aula.getId_usuario());
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.out.println("Error al guardar: " + e.getMessage());
            return false;
        }
    }

    public List<Object[]> obtenerTodasConDocente() {
        List<Object[]> lista = new ArrayList<>();
        String sql = "SELECT a.id_aula, a.nombre_aula, a.capacidad, a.descripcion, "
                   + "g.numero_grado, s.letra_grupo, "
                   + "u.nombres, u.apellidos "
                   + "FROM aula a "
                   + "LEFT JOIN grado g ON a.id_grado = g.id_grado "
                   + "LEFT JOIN seccion s ON a.id_seccion = s.id_seccion "
                   + "LEFT JOIN usuario u ON a.id_usuario = u.id_usuario";
        try (Connection conexion = Conexion.conectar();
             PreparedStatement ps = conexion.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                Object[] fila = new Object[8];
                fila[0] = rs.getInt("id_aula");
                fila[1] = rs.getString("nombre_aula");
                fila[2] = rs.getInt("capacidad");
                fila[3] = rs.getString("descripcion");
                fila[4] = rs.getObject("numero_grado");
                fila[5] = rs.getString("letra_grupo");
                String nombreDocente = rs.getString("nombres");
                String apellidoDocente = rs.getString("apellidos");
                fila[6] = (nombreDocente != null)
                        ? nombreDocente + " " + apellidoDocente
                        : "Sin asignar";
                lista.add(fila);
            }
        } catch (SQLException e) {
            System.out.println("Error al obtener aulas: " + e.getMessage());
        }
        return lista;
    }

    public boolean eliminarAula(int id) {
        String sql = "DELETE FROM aula WHERE id_aula=?";
        try (Connection con = Conexion.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            int resultado = ps.executeUpdate();
            return resultado > 0;
        } catch (SQLException ex) {
            System.out.println("Error al eliminar aula: " + ex.getMessage());
            return false;
        }
    }

    public Aula buscarPorId(int idAula) {
        String sql = "SELECT * FROM aula WHERE id_aula = ?";
        try (Connection con = Conexion.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, idAula);  
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    Aula a = new Aula();
                    a.setIdAula(rs.getInt("id_aula"));
                    a.setNombreAula(rs.getString("nombre_aula"));
                    a.setCapacidad(rs.getInt("capacidad"));
                    a.setDescripcion(rs.getString("descripcion"));
                    a.setIdSeccion(rs.getInt("id_seccion"));
                    a.setId_grado(rs.getInt("id_grado"));
                    a.setId_usuario(rs.getInt("id_usuario"));
                    return a;
                }
            }
        } catch (SQLException ex) {
            System.out.println("Error al buscar aula: " + ex.getMessage());
        }
        return null;
    }

    public int contarAulasPorSeccion(int idSeccion) {
        return contarUsos("aula", "id_seccion", idSeccion);
    }

    public int contarAulasPorGrado(int idGrado) {
        return contarUsos("aula", "id_grado", idGrado);
    }

    public int contarEstudiantesPorSeccion(int idSeccion) {
        return contarUsos("estudiante", "id_seccion", idSeccion);
    }

    public int contarEstudiantesPorGrado(int idGrado) {
        return contarUsos("estudiante", "id_grado", idGrado);
    }

    private int contarUsos(String tabla, String columna, int id) {
        String sql = "SELECT COUNT(*) FROM " + tabla + " WHERE " + columna + " = ?";
        try (Connection con = Conexion.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1);
                }
            }
        } catch (SQLException ex) {
            System.out.println("Error al contar usos en " + tabla + ": " + ex.getMessage());
        }
        return 0;
    }
}