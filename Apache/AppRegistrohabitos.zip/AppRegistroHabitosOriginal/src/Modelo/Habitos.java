/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author jhon Fonseca
 */
public class Habitos {
    private int id_habitos;
    private String tipo_de_habito;
    private String nombre_de_habito;
    private String unidad_de_medida;
    private String frecuencia;

    public Habitos(int id_habitos, String tipo_de_habito, String nombre_de_habito, String unidad_de_medida, String frecuencia) {
        this.id_habitos = id_habitos;
        this.tipo_de_habito = tipo_de_habito;
        this.nombre_de_habito = nombre_de_habito;
        this.unidad_de_medida = unidad_de_medida;
        this.frecuencia = frecuencia;
    }

    public Habitos() {
    }
    
    public Habitos(String tipo_de_habito, String nombre_de_habito, String unidad_de_medida) {
        this.tipo_de_habito = tipo_de_habito;
        this.nombre_de_habito = nombre_de_habito;
        this.unidad_de_medida = unidad_de_medida;
    }

    public int getId_habitos() {
        return id_habitos;
    }

    public void setId_habitos(int id_habitos) {
        this.id_habitos = id_habitos;
    }

    public String getTipo_de_habito() {
        return tipo_de_habito;
    }

    public void setTipo_de_habito(String tipo_de_habito) {
        this.tipo_de_habito = tipo_de_habito;
    }

    public String getNombre_de_habito() {
        return nombre_de_habito;
    }

    public void setNombre_de_habito(String nombre_de_habito) {
        this.nombre_de_habito = nombre_de_habito;
    }

    public String getUnidad_de_medida() {
        return unidad_de_medida;
    }

    public void setUnidad_de_medida(String unidad_de_medida) {
        this.unidad_de_medida = unidad_de_medida;
    }

    public String getFrecuencia() {
        return frecuencia;
    }

    public void setFrecuencia(String frecuencia) {
        this.frecuencia = frecuencia;
    }

    
}
