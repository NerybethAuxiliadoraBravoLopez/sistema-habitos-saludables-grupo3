/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;
import Conexion.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;   
import java.sql.SQLException;

import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author jhon Fonseca
 */
public class GradoDAO {
   
    
  public int guardar(Grado grado) {
    String sql = "INSERT INTO grado (numero_grado) VALUES (?)";
    try (Connection conexion = Conexion.conectar();
         PreparedStatement ps = conexion.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS)) {
        ps.setInt(1, grado.getNumeroGrado());
        ps.executeUpdate();
        try (ResultSet rs = ps.getGeneratedKeys()) {
            if (rs.next()) {
                return rs.getInt(1); // id generado
            }
        }
        return -1;
    } catch (SQLException e) {
        System.out.println("Error al guardar grado: " + e.getMessage());
        return -1;
    }
}


public List<Grado> listarGrados() {
    List<Grado> lista = new ArrayList<>();
    String sql = "SELECT * FROM grado ORDER BY numero_grado";

    try (Connection con = Conexion.conectar();
         PreparedStatement ps = con.prepareStatement(sql);
         ResultSet rs = ps.executeQuery()) {

        while (rs.next()) {
            Grado g = new Grado();
            g.setId_grado(rs.getInt("id_grado"));
            g.setNumeroGrado(rs.getInt("numero_grado"));
            lista.add(g);
        }

    } catch (SQLException ex) {
        System.out.println("Error al listar grados: " + ex.getMessage());
    }
    return lista;
}
public boolean eliminargrado(int idGrado){
    String sql = "DELETE FROM grado WHERE id_grado=?";
    try (Connection con = Conexion.conectar();
         PreparedStatement ps = con.prepareStatement(sql)) {
        ps.setInt(1, idGrado);
        int resultado = ps.executeUpdate();
        return resultado > 0;
    } catch (SQLException ex) {
        System.out.println("Error al eliminar grado: " + ex.getMessage());
        return false;
    }
}

}
