/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;


public class Seccion {
    private int id_seccion;
    private String letra_grupo;

    public Seccion() {
    }

    public Seccion(String letra_grupo) {
        this.letra_grupo = letra_grupo;
    }

    public int getId_seccion() {
        return id_seccion;
    }

    public void setId_seccion(int id_seccion) {
        this.id_seccion = id_seccion;
    }

    public String getLetra_grupo() {
        return letra_grupo;
    }

    public void setLetra_grupo(String letra_grupo) {
        this.letra_grupo = letra_grupo;
    }
}