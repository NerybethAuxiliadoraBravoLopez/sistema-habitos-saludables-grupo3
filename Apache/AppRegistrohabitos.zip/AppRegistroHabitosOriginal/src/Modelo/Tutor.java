/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author jhon Fonseca
 */
public class Tutor {
    public int id_tutor;
      public String nombres;
    public String apellidos;
    public String correos;
    public String telefono;

    public Tutor() {
    }

    public Tutor(int id_tutor, String nombres, String apellidos, String correos, String telefono) {
        this.id_tutor = id_tutor;
        this.nombres = nombres;
        this.apellidos = apellidos;
        this.correos = correos;
        this.telefono = telefono;
    }

    public int getId_tutor() {
        return id_tutor;
    }

    public void setId_tutor(int id_tutor) {
        this.id_tutor = id_tutor;
    }

    public String getNombres() {
        return nombres;
    }

    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String getCorreos() {
        return correos;
    }

    public void setCorreos(String correos) {
        this.correos = correos;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }
}